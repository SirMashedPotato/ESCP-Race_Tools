﻿using UnityEngine;
using Verse;
using System;

namespace StandaloneSettlementPreference
{
    class SettlementPreference_Mod : Mod
    {
        SettlementPreference_ModSettings settings;

        public SettlementPreference_Mod(ModContentPack contentPack) : base(contentPack)
        {
            this.settings = GetSettings<SettlementPreference_ModSettings>();
        }

        public override string SettingsCategory() => "StandaloneSettlementPreference_ModName".Translate();

        public override void DoSettingsWindowContents(Rect inRect)
        {
            Listing_Standard listing_Standard = new Listing_Standard();
            listing_Standard.Begin(inRect);
            listing_Standard.Gap();

            listing_Standard.CheckboxLabeled("StandaloneSettlementPreference_EnableSettlementPreference".Translate(), ref settings.StandaloneSettlementPreference_EnableSettlementPreference, "StandaloneSettlementPreference_EnableSettlementPreferenceTooltip".Translate() + TooltipStringInit.General_SettlementPreference);
            listing_Standard.Gap();

            listing_Standard.Label("StandaloneSettlementPreference_Iterations".Translate() + " (" + settings.StandaloneSettlementPreference_Iterations + ")", -1, "ESCP_RaceTools_SettlementPreferenceIterationsTooltip".Translate());
            settings.StandaloneSettlementPreference_Iterations = (int)Math.Round(listing_Standard.Slider(settings.StandaloneSettlementPreference_Iterations, 10, 5000) / 10) * 10;
            listing_Standard.Gap();

            if (Prefs.DevMode)
            {
                listing_Standard.CheckboxLabeled("StandaloneSettlementPreference_Logging".Translate(), ref settings.StandaloneSettlementPreference_Logging, "StandaloneSettlementPreference_LoggingTooltip".Translate());
                listing_Standard.Gap();

                listing_Standard.CheckboxLabeled("StandaloneSettlementPreference_LoggingExtended".Translate(), ref settings.StandaloneSettlementPreference_LoggingExtended, "StandaloneSettlementPreference_LoggingExtendedTooltip".Translate());
                listing_Standard.Gap();
            }

            listing_Standard.GapLine();
            listing_Standard.Gap();

            Rect rectDefault = listing_Standard.GetRect(30f);
            TooltipHandler.TipRegion(rectDefault, "StandaloneSettlementPreference_ResetSettings".Translate());
            if (Widgets.ButtonText(rectDefault, "StandaloneSettlementPreference_ResetSettings".Translate(), true, true, true))
            {
                SettlementPreference_ModSettings.ResetSettings();
            }

            listing_Standard.End();
            base.DoSettingsWindowContents(inRect);
        }
    }
}

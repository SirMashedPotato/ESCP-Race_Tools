﻿using Verse;

namespace StandaloneSettlementPreference
{
    class SettlementPreference_ModSettings : ModSettings
    {
        private static SettlementPreference_ModSettings _instance;

        public static bool Enable_SettlementPreference
        {
            get
            {
                return _instance.StandaloneSettlementPreference_EnableSettlementPreference;
            }
        }

        public static bool Enable_Logging
        {
            get
            {
                return _instance.StandaloneSettlementPreference_Logging;
            }
        }

        public static bool Enable_LoggingExtra
        {
            get
            {
                return _instance.StandaloneSettlementPreference_LoggingExtended;
            }
        }

        public static int Count_MaxIterations
        {
            get
            {
                return _instance.StandaloneSettlementPreference_Iterations;
            }
        }

        public static void ResetSettings()
        {
            _instance.StandaloneSettlementPreference_EnableSettlementPreference = true;
            _instance.StandaloneSettlementPreference_Logging = false;
            _instance.StandaloneSettlementPreference_LoggingExtended = false;
            _instance.StandaloneSettlementPreference_Iterations = 50;
        }

        public bool StandaloneSettlementPreference_EnableSettlementPreference = true;
        public bool StandaloneSettlementPreference_Logging = false;
        public bool StandaloneSettlementPreference_LoggingExtended = false;
        public int StandaloneSettlementPreference_Iterations = 50;

        public SettlementPreference_ModSettings()
        {
            _instance = this;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref StandaloneSettlementPreference_EnableSettlementPreference, "StandaloneSettlementPreference_EnableSettlementPreference", true);
            Scribe_Values.Look(ref StandaloneSettlementPreference_Logging, "StandaloneSettlementPreference_Logging", false);
            Scribe_Values.Look(ref StandaloneSettlementPreference_LoggingExtended, "StandaloneSettlementPreference_LoggingExtended", false);
            Scribe_Values.Look(ref StandaloneSettlementPreference_Iterations, "StandaloneSettlementPreference_Iterations", 50);
        }
    }
}

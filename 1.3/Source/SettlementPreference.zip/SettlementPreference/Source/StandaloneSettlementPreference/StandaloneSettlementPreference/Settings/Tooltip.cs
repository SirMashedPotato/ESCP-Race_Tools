﻿using Verse;
using System;
using System.Linq;
using System.Collections.Generic;
using RimWorld;

namespace StandaloneSettlementPreference
{
    [StaticConstructorOnStartup]
    public static class TooltipStringInit
    {
        public static string General_SettlementPreference;

        static TooltipStringInit()
        {
            General_SettlementPreference = General_SettlementPreference_Init();
        }

        /* Resulting output is: - [MODNAME] (x faction/s) */
        public static string General_SettlementPreference_Init()
        {
            string factions = "";
            List<string> mods = new List<string> { };
            List<int> duplications = new List<int> { };
            int other = 0;

            DefDatabase<FactionDef>.AllDefsListForReading.Where(x => SettlementPreference.Get(x) != null).ToList().ForEach(action: def =>
            {
                if (def.modContentPack != null)
                {
                    if (!mods.Contains(def.modContentPack.Name))
                    {
                        mods.Add(def.modContentPack.Name);
                        duplications.Add(1);
                    }
                    else
                    {
                        duplications[duplications.Count - 1]++;
                    }
                }
                else
                {
                    other++;
                }

            });

            if (!mods.NullOrEmpty())
            {
                for (int i = 0; i < mods.Count; i++)
                {
                    factions += "\n - " + mods[i] + " (" + duplications[i] + " faction/s)";
                }
            }

            if (factions == "")
            {
                factions = "\n - None";
            }

            if (other > 0)
            {
                factions += "\n - " + "Other" + " (" + other + " faction/s)";
            }

            return factions;
        }
    }
}
